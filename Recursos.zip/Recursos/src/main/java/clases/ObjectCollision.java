/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

public abstract class ObjectCollision extends Thread{
    protected final ArrayList<CollisionController> colisiones = new ArrayList();
    protected final Sprite sprite;
    protected String ID;

    public ObjectCollision(String ID, Sprite sprite) {
        this.ID = ID;
        this.sprite = sprite;
    }

    public Sprite getSprite() {
        return sprite;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    
    public ArrayList<CollisionController> getColisiones() {
        return colisiones;
    }
    
    public void addColision(ObjectCollision objeto){
        CollisionController c = new CollisionController(objeto, this, objeto.getColision(), getColision());
        this.colisiones.add(c);
    }
    
    public Colision getColision(){
        return this.sprite.getColision();
    }
    
    public abstract void Colision(ObjectCollision objeto);
    
    public void verificarColision(){
        try {
            for (CollisionController c : colisiones) {
                c.verificarColision();
            }
            
            sleep(1);
        } catch (Exception e) {}
    }
    
    @Override
    public abstract void run();
}
