/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Sprite extends Thread{
    private Imagen imagen;
    private Colision colision;
    private JLabel label;
    private int x, y, centroX, centroY;
    private final ArrayList<Imagen> imagenes = new ArrayList(); // En caso de tener distintas animaciones
    private int imPos = 0; // posicion de la imagen a usar
    
    public Sprite(Imagen imagen, Colision colision) {
        this.imagen = imagen;
        this.colision = colision;
        
        crearLabel();
    }
    
    public Sprite(String direccion, Colision colision) {
        this.imagen = new Imagen(direccion);
        this.colision = colision;
        
        crearLabel();
    }
    
    public Sprite(Imagen imagen) {
        this.imagen = imagen;
        
        crearLabel();
    }
    
    public Sprite(String direccion) {
        this.imagen = new Imagen(direccion);
        
        crearLabel();
    }
    
    private void crearLabel(){
        if(this.colision == null) // de no existir una colision crea una
            this.colision = new Colision(x, y, imagen.getImagen().getIconWidth(), imagen.getImagen().getIconHeight());
        
        this.imagenes.add(this.imagen);
        ImageIcon im = this.imagen.getImagen();
        this.label = new JLabel(im);
        this.label.setSize(im.getIconWidth(), im.getIconHeight());
        
        this.centroX = im.getIconWidth() / 2;
        this.centroY = im.getIconHeight() / 2;
        
        this.colision.setCentro(this.centroX, this.centroY);
    }
    
    public void addImagen(Imagen imagen){
        this.imagenes.add(imagen);
    }
    
    /**
     * Cambia el objeto Imagen a utilizar, 
     * en caso de tener distintas animaciones.
     * 
     * @param pos 
     * Posición en la lista.
     */
    public void cambiarImagen(int pos){
        if(pos >= 0 && pos < this.imagenes.size()){
            this.imagen = this.imagenes.get(pos);
            this.imPos = pos;
        }
    }

    public ArrayList<Imagen> getImagenes() {
        return imagenes;
    }

    public int getImPos() {
        return imPos;
    }
    
    public void setPosicion(int x, int y){
        this.x = x;
        this.y = y;
        
        if(this.colision != null)
            this.colision.setPosicion(x, y);
        this.label.setLocation(x, y);
    }

    public void setColision(Colision colision) {
        this.colision = colision;
    }
    
    public Imagen getImagen() {
        return imagen;
    }
    
    public ImageIcon getImageIcon(){
        return this.imagen.getImagen();
    }
    
    public Colision getColision() {
        return colision;
    }

    public JLabel getLabel() {
        return label;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    @Override
    public void run(){
        while(true){
            imagen.cambiarFrame();
            label.setIcon(imagen.getImagen());
        }
    }
}
