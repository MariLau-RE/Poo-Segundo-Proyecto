package clases;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Archivo {
    private final File archivo;
    private final String nombre;
    private final String direccion;
    
    /**
     * Crea o abre un archivo con el nombre indicado en una dirección predefinida.
     * 
     * @param nombre 
     * Nombre del archivo con su extención.
     */
    public Archivo(String nombre){
        this.nombre = nombre;
        
        this.archivo = new File(nombre);
        //Creea el archivo si no existe
        if(!archivo.exists())
            crearArchivo();
        
        this.direccion = archivo.getAbsolutePath().replaceFirst(nombre, "");
    }
    
    /**
     * Crea o abre un archivo con el nombre indicado.
     * 
     * @param nombre
     * Nombre del archivo con su extención.
     * 
     * @param direccion
     * Dirección en la que se ubica o creará el archivo.
     */
    public Archivo(String nombre, String direccion){
        this.nombre = nombre;
        
        this.archivo = new File(direccion + nombre);
        //Creea el archivo si no existe
        if(!archivo.exists())
            crearArchivo();
        
        this.direccion = archivo.getAbsolutePath().replaceFirst(nombre, "");
    }
    
    private void crearArchivo(){
        try {
            BufferedWriter bw;
            bw = new BufferedWriter(new FileWriter(archivo));
            bw.write("");
            bw.close();
        } catch (Exception e) {}
    }
    
    public File getArchivo() {
        return archivo;
    }
    
    /**
     * Lee y retorna el contenido del archivo.
     * 
     * @return String
     * Contenido del archivo.
     */
    public String getTexto(){
        String texto = ""; 
        try{
            BufferedReader br = new BufferedReader(new FileReader(this.archivo));
            String linea;
            
            while((linea = br.readLine()) != null) // Si hay algo en la linea
                texto += linea + "\n";
            return texto;
            
        } catch(Exception e){}
        
        return null;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }
    
    /**
     * Escribe en el archivo el String entrante borrando el contenido previo.
     * 
     * @param texto 
     * String que se desea guardar.
     */
    public void setTexto(String texto){
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(this.archivo));
            bw.write(texto);
            bw.close();
        }catch(Exception e){}
    }

    @Override
    public String toString() {
        return getTexto();
    }
    
    
}