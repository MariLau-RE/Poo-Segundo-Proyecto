/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import static java.lang.Thread.sleep;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class Imagen{
    private boolean animacion = false;
    private final ArrayList<ImageIcon> imagenes = new ArrayList();
    private int posicion = 0; // posicion de la imagen a retornar
    private int velocidad = 0; // velocidad de cambio de imagen (0 indica el valor por defecto)
    private final String direccion;
    
    /**
     * Abre una imagen existente como objeto ImageIcon.
     * 
     * @param direccion 
     * Ubicacíon exacta de la imagen a abrir.
     */
    public Imagen(String direccion) {
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
        this.direccion = direccion;
    }
    
    /**
     * Abre una imagen existente como objeto ImageIcon.
     * 
     * @param direccion 
     * Ubicacíon exacta de la imagen a abrir.
     * @param animacion 
     * Indica si este objeto se Imagen se utilizará como animación, 
     * conteniendo "n" imagenes cargadas.
     */
    public Imagen(String direccion, boolean animacion) {
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
        this.animacion = animacion;
        this.direccion = direccion;
    }
    
    /**
     * Carga y agrega una nueva imagen.
     * 
     * @param direccion 
     * Ubicacíon exacta de la imagen a abrir.
     */
    public void addImagen(String direccion){
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
    }

    public String getDireccion() {
        return direccion;
    }
    
    public ImageIcon getImagen() {
        return this.imagenes.get(this.posicion);
    }

    public boolean isAnimacion() {
        return animacion;
    }

    public void setAnimacion(boolean animacion) {
        this.animacion = animacion;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<ImageIcon> getImagenes() {
        return imagenes;
    }
    
    /**
     * Remplaza una imagen en una posición específica.
     * 
     * @param imagen
     * @param pos 
     * Posición de la imagen a remplazar.
     */
    public void setImagen(ImageIcon imagen, int pos){
        this.imagenes.remove(pos);
        this.imagenes.add(pos, imagen);
    }
    
    public void cancelarCambio(){
        this.animacion = false;
    }
    
    /**
     * Cambia la posición de la imagen a retornar y espera un tiempo previamente
     * definido, cambiando los frames de la animación.
     */
    public void cambiarFrame(){
        int j;
        if(this.velocidad == 0)
            j = 250;
        else
            j = this.velocidad;
        
        if(this.animacion){
            if(this.posicion < this.imagenes.size() - 1)
                this.posicion ++;
            else
                this.posicion = 0;
        }
        for (int i = 0; i < j; i++) {
            if(this.animacion){
                try {
                    sleep(1);
                } catch (Exception e) {}
            }
            else{
                this.animacion = true;
                break;
            }
        }
    }
}
