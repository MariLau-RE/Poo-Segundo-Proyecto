/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

public class Tiempo extends Thread{
    private int segundos;
    private int minutos;
    private boolean iniciado;

    public Tiempo() {
        this.iniciado = false;
        this.segundos = 0;
        this.minutos = 0;
        
        this.start();
    }
    
    public void iniciar(){
        this.iniciado = true;
    }
    
    public void pausar(){
        this.iniciado = false;
    }
    
    public void reiniciar(){
        pausar();
        this.segundos = 0;
        this.minutos = 0;
        iniciar();
    }

    public int getSegundos() {
        return segundos;
    }

    public int getMinutos() {
        return minutos;
    }
    
    @Override
    public void run(){
        try {
            while(this.iniciado){
                sleep(1000);
                this.segundos ++;
                
                if(this.segundos == 60){
                   this.segundos = 0;
                   this.minutos ++;
                }
            }
        } catch (Exception e) {}
    }
}
